const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const User = require('../models/User');
const { roleMiddleware } = require('../middleware/auth');
const authRoutes = require('./routes/auth');
app.use('/auth', authRoutes);





// Страница логина
router.get('/login', (req, res) => {
  res.render('login', { message: null });
});

// Страница регистрации
router.get('/register', (req, res) => {
  res.render('register', { message: null, success: null });
});

// Регистрация
router.post('/register', async (req, res) => {
  const { username, password, firstName, lastName, age, gender, role } = req.body;

  try {
    const user = new User({ username, password, firstName, lastName, age, gender, role });
    await user.save();

    res.render('register', {
      message: `Добро пожаловать, ${user.username}! Регистрация успешна.`,
      success: true,
    });
  } catch (error) {
    res.render('register', {
      message: `Ошибка регистрации: ${error.message}`,
      success: false,
    });
  }
});

// Логин
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.render('login', {
        message: 'Неверное имя пользователя или пароль.',
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.render('login', {
        message: 'Неверное имя пользователя или пароль.',
      });
    }

    // Сохранение данных пользователя в сессии
    req.session.user = {
      id: user._id,
      username: user.username,
      role: user.role,
    };

    // Перенаправляем на dashboard
    res.redirect('/dashboard');
  } catch (error) {
    res.status(500).render('login', {
      message: 'Ошибка сервера. Попробуйте снова.',
    });
  }
});

// Dashboard
router.get('/dashboard', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/auth/login');
  }

  res.render('dashboard', { user: req.session.user });
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send('Ошибка при выходе.');
    }
    res.redirect('/auth/login'); // Перенаправляем на страницу входа
  });
});


// Пример защищённого маршрута (только для admin)
router.get('/admin-only', roleMiddleware(['admin']), (req, res) => {
  res.send('Это страница только для администраторов.');
});

module.exports = router;
